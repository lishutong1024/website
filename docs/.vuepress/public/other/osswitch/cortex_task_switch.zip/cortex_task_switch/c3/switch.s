    .text
    .global task_switch
task_switch:
    bx r0