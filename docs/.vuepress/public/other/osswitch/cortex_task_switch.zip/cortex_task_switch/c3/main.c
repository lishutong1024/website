
int func2 (void) {
    return 2;
}

int func1 (void) {
    int res = func2();
    return res;
}

void task_0_entry (void);
void task_1_entry (void);

void task_switch (unsigned int to_addr);

void task_0_entry (void) {
    int count = -1;
    
    for (;;) {
        count++;
        task_switch((unsigned int)task_1_entry);
    }
}

void task_1_entry (void) {
    int count = 0;
    
    for (;;) {
        count++;
        task_switch((unsigned int)task_0_entry);
    }
}

int main (void) {
    task_switch((unsigned int)task_0_entry);
    for (;;) {}
    return 0;
}
