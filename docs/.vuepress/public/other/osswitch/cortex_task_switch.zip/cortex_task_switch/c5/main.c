
int func2 (void) {
    return 2;
}

int func1 (void) {
    int res = func2();
    return res;
}

struct task_context_t {
    unsigned int return_addr;
    unsigned int stack_addr;
}task0, task1;

void task_switch (struct task_context_t * from, struct task_context_t * to);
void task_run_first (struct task_context_t * to);

void task_0_entry (void);
void task_1_entry (void);

void task_0_entry (void) {
    int count = -1;
    
    for (;;) {
        count++;
        task_switch(&task0, &task1);
    }
}

void task_1_entry (void) {
    int count = 0;

    for (;;) {
        count++;
        task_switch(&task1, &task0);
    }
}

unsigned int task0_stack[80];
unsigned int task1_stack[80];

int main (void) {
    task0.return_addr = (unsigned int)task_0_entry;
    task0.stack_addr = (unsigned int)&task0_stack[80];
    task1.return_addr = (unsigned int)task_1_entry;
    task1.stack_addr = (unsigned int)&task1_stack[80];
    task_run_first(&task0);
    for (;;) {}
    return 0;
}
