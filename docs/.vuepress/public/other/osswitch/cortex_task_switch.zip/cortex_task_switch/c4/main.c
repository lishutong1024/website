
int func2 (void) {
    return 2;
}

int func1 (void) {
    int res = func2();
    return res;
}

void task_0_entry (void);
void task_1_entry (void);

void task_switch (unsigned int * from_addr, unsigned int to_addr);
void task_run_first (unsigned int to_addr);

unsigned int task0_return_addr;
unsigned int task1_return_addr;

void task_0_entry (void) {
    int count = -1;
    
    for (;;) {
        count++;
        task_switch(&task0_return_addr, task1_return_addr);
    }
}

void task_1_entry (void) {
    int count = 0;

    for (;;) {
        count++;
        task_switch(&task1_return_addr, task0_return_addr);
    }
}

int main (void) {
    task0_return_addr = (unsigned int)task_0_entry;
    task1_return_addr = (unsigned int)task_1_entry;
    task_run_first(task0_return_addr);
    for (;;) {}
    return 0;
}
