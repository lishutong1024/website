    .text
    .global task_switch
    .global task_run_first
task_switch:
    // save to from_addr
    str lr, [r0]
    
    // jmp to addr
    bx r1

task_run_first:
    bx r0
