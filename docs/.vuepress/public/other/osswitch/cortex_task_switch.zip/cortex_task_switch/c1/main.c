
int func2 (void) {
    return 2;
}

int func1 (void) {
    int res = func2();
    return res;
}

int main (void) {
    func1();
    for (;;) {}
    return 0;
}
