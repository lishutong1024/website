
int func1 (void) {
    return 0;
}

int main (void) {
    func1();
    for (;;) {}
    return 0;
}
