    .text
    .global task_switch
    .global task_run_first
task_switch:
    // save to from_addr
    str lr, [r0]
    
    // save sp
    str sp, [r0, 4]
    
    // load sp
    ldr sp, [r1, 4]
    
    // load pc
    ldr pc, [r1, 0]

task_run_first:
    // load sp
    ldr sp, [r0, 4*14]

    // load apsr
    ldr r2, [r0, 4*15]
    msr apsr, r2

    // load r0-r12
    ldmia r0, {r0-r12, pc}
